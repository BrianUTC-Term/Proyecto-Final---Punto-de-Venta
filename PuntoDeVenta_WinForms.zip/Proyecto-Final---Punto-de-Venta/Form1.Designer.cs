﻿﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitulo = new Label();
            btnFacturacion = new Button();
            btnProductos = new Button();
            btnClientes = new Button();
            btnEstadisticas = new Button();
            btnSalir = new Button();
            SuspendLayout();
            //
            // lblTitulo
            //
            lblTitulo.AutoSize = true;
            lblTitulo.Location = new Point(30, 20);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(172, 15);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Sistema de Ventas - TechStore";
            //
            // btnFacturacion
            //
            btnFacturacion.Location = new Point(30, 50);
            btnFacturacion.Name = "btnFacturacion";
            btnFacturacion.Size = new Size(240, 35);
            btnFacturacion.TabIndex = 1;
            btnFacturacion.Text = "Facturación (Punto de Venta)";
            btnFacturacion.UseVisualStyleBackColor = true;
            btnFacturacion.Click += btnFacturacion_Click;
            //
            // btnProductos
            //
            btnProductos.Location = new Point(30, 95);
            btnProductos.Name = "btnProductos";
            btnProductos.Size = new Size(240, 35);
            btnProductos.TabIndex = 2;
            btnProductos.Text = "Productos";
            btnProductos.UseVisualStyleBackColor = true;
            btnProductos.Click += btnProductos_Click;
            //
            // btnClientes
            //
            btnClientes.Location = new Point(30, 140);
            btnClientes.Name = "btnClientes";
            btnClientes.Size = new Size(240, 35);
            btnClientes.TabIndex = 3;
            btnClientes.Text = "Clientes";
            btnClientes.UseVisualStyleBackColor = true;
            btnClientes.Click += btnClientes_Click;
            //
            // btnEstadisticas
            //
            btnEstadisticas.Location = new Point(30, 185);
            btnEstadisticas.Name = "btnEstadisticas";
            btnEstadisticas.Size = new Size(240, 35);
            btnEstadisticas.TabIndex = 4;
            btnEstadisticas.Text = "Estadísticas";
            btnEstadisticas.UseVisualStyleBackColor = true;
            btnEstadisticas.Click += btnEstadisticas_Click;
            //
            // btnSalir
            //
            btnSalir.Location = new Point(30, 240);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(240, 35);
            btnSalir.TabIndex = 5;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            //
            // Form1
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(300, 300);
            Controls.Add(btnSalir);
            Controls.Add(btnEstadisticas);
            Controls.Add(btnClientes);
            Controls.Add(btnProductos);
            Controls.Add(btnFacturacion);
            Controls.Add(lblTitulo);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sistema de Ventas - TechStore";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitulo;
        private Button btnFacturacion;
        private Button btnProductos;
        private Button btnClientes;
        private Button btnEstadisticas;
        private Button btnSalir;
    }
}

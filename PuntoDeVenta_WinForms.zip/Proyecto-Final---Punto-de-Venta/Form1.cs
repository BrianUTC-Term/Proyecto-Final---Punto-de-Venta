using WinFormsApp1.Formularios;

namespace WinFormsApp1
{
    // Menu principal del sistema (equivale a MenuPrincipal de la consola)
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnFacturacion_Click(object sender, EventArgs e)
        {
            using var frm = new FrmFacturacion();
            frm.ShowDialog(this);
        }

        private void btnProductos_Click(object sender, EventArgs e)
        {
            using var frm = new FrmProductos();
            frm.ShowDialog(this);
        }

        private void btnClientes_Click(object sender, EventArgs e)
        {
            using var frm = new FrmClientes();
            frm.ShowDialog(this);
        }

        private void btnEstadisticas_Click(object sender, EventArgs e)
        {
            using var frm = new FrmEstadisticas();
            frm.ShowDialog(this);
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

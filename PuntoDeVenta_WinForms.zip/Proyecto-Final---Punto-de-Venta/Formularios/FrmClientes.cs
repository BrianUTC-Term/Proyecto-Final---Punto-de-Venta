using WinFormsApp1.Modelos;
using WinFormsApp1.Negocio;

namespace WinFormsApp1.Formularios
{
    // Mantenimiento de clientes: listar, buscar, agregar, modificar y eliminar
    public partial class FrmClientes : Form
    {
        // Id del cliente seleccionado (0 = cliente nuevo)
        private int idSeleccionado = 0;

        public FrmClientes()
        {
            InitializeComponent();
        }

        private void FrmClientes_Load(object sender, EventArgs e)
        {
            CargarClientes();
        }

        // Carga la tabla con todos los clientes o con el resultado de la busqueda
        private void CargarClientes()
        {
            try
            {
                dgvClientes.DataSource = ClienteNegocio.Buscar(txtBuscar.Text.Trim());
                dgvClientes.ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los clientes: " + ex.Message, "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarClientes();
        }

        // Al seleccionar una fila se pasan los datos a los campos
        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (dgvClientes.Rows[e.RowIndex].DataBoundItem is Cliente c)
            {
                idSeleccionado = c.Id;
                txtNombre.Text = c.Nombre;
                txtTelefono.Text = c.Telefono;
                txtCorreo.Text = c.Correo;
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            var cliente = new Cliente
            {
                Id = idSeleccionado,
                Nombre = txtNombre.Text.Trim(),
                Telefono = txtTelefono.Text.Trim(),
                Correo = txtCorreo.Text.Trim()
            };

            try
            {
                if (idSeleccionado == 0)
                {
                    ClienteNegocio.Agregar(cliente);
                    MessageBox.Show("Cliente agregado.", "Clientes");
                }
                else
                {
                    ClienteNegocio.Actualizar(cliente);
                    MessageBox.Show("Cliente actualizado.", "Clientes");
                }

                Limpiar();
                CargarClientes();
            }
            catch (NegocioException ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message, "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un cliente de la lista.", "Clientes");
                return;
            }

            if (MessageBox.Show("¿Confirmar eliminación?", "Clientes", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                ClienteNegocio.Eliminar(idSeleccionado);
                MessageBox.Show("Cliente eliminado.", "Clientes");
                Limpiar();
                CargarClientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo eliminar: " + ex.Message, "Clientes", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Deja los campos listos para un cliente nuevo
        private void Limpiar()
        {
            idSeleccionado = 0;
            txtNombre.Clear();
            txtTelefono.Clear();
            txtCorreo.Clear();
            dgvClientes.ClearSelection();
            txtNombre.Focus();
        }
    }
}

﻿namespace WinFormsApp1.Formularios
{
    partial class FrmEstadisticas
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMasVendidos = new Button();
            btnClientesFrecuentes = new Button();
            btnStockBajo = new Button();
            btnCerrar = new Button();
            lblResultado = new Label();
            lstResultados = new ListBox();
            SuspendLayout();
            //
            // btnMasVendidos
            //
            btnMasVendidos.Location = new Point(12, 30);
            btnMasVendidos.Name = "btnMasVendidos";
            btnMasVendidos.Size = new Size(180, 35);
            btnMasVendidos.TabIndex = 0;
            btnMasVendidos.Text = "Productos más vendidos";
            btnMasVendidos.UseVisualStyleBackColor = true;
            btnMasVendidos.Click += btnMasVendidos_Click;
            //
            // btnClientesFrecuentes
            //
            btnClientesFrecuentes.Location = new Point(12, 75);
            btnClientesFrecuentes.Name = "btnClientesFrecuentes";
            btnClientesFrecuentes.Size = new Size(180, 35);
            btnClientesFrecuentes.TabIndex = 1;
            btnClientesFrecuentes.Text = "Clientes más frecuentes";
            btnClientesFrecuentes.UseVisualStyleBackColor = true;
            btnClientesFrecuentes.Click += btnClientesFrecuentes_Click;
            //
            // btnStockBajo
            //
            btnStockBajo.Location = new Point(12, 120);
            btnStockBajo.Name = "btnStockBajo";
            btnStockBajo.Size = new Size(180, 35);
            btnStockBajo.TabIndex = 2;
            btnStockBajo.Text = "Productos con stock bajo";
            btnStockBajo.UseVisualStyleBackColor = true;
            btnStockBajo.Click += btnStockBajo_Click;
            //
            // btnCerrar
            //
            btnCerrar.Location = new Point(12, 275);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.Size = new Size(180, 35);
            btnCerrar.TabIndex = 3;
            btnCerrar.Text = "Cerrar";
            btnCerrar.UseVisualStyleBackColor = true;
            btnCerrar.Click += btnCerrar_Click;
            //
            // lblResultado
            //
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(210, 12);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(157, 15);
            lblResultado.TabIndex = 4;
            lblResultado.Text = "Seleccione una estadística";
            //
            // lstResultados
            //
            lstResultados.FormattingEnabled = true;
            lstResultados.ItemHeight = 15;
            lstResultados.Location = new Point(210, 30);
            lstResultados.Name = "lstResultados";
            lstResultados.Size = new Size(360, 274);
            lstResultados.TabIndex = 5;
            //
            // FrmEstadisticas
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(584, 322);
            Controls.Add(lstResultados);
            Controls.Add(lblResultado);
            Controls.Add(btnCerrar);
            Controls.Add(btnStockBajo);
            Controls.Add(btnClientesFrecuentes);
            Controls.Add(btnMasVendidos);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmEstadisticas";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Estadísticas";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnMasVendidos;
        private Button btnClientesFrecuentes;
        private Button btnStockBajo;
        private Button btnCerrar;
        private Label lblResultado;
        private ListBox lstResultados;
    }
}

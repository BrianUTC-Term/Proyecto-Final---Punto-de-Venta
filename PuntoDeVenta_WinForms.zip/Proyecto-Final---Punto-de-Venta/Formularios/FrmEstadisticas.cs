using WinFormsApp1.Negocio;

namespace WinFormsApp1.Formularios
{
    // Estadisticas: mismas consultas LINQ que MenuEstadisticas de la consola
    public partial class FrmEstadisticas : Form
    {
        private const int UmbralStockBajo = 10;

        public FrmEstadisticas()
        {
            InitializeComponent();
        }

        // Producto mas vendido: se agrupan con LINQ todos los detalles de venta
        private void btnMasVendidos_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "Productos más vendidos";
            lstResultados.Items.Clear();

            try
            {
                var top = VentaNegocio.ObtenerDetallesVendidos()
                    .GroupBy(d => d.ProductoNombre)
                    .Select(g => new { Producto = g.Key, Total = g.Sum(x => x.Cantidad) })
                    .OrderByDescending(x => x.Total)
                    .Take(5)
                    .ToList();

                if (top.Count == 0)
                {
                    lstResultados.Items.Add("Aún no hay ventas registradas.");
                    return;
                }
                foreach (var item in top)
                    lstResultados.Items.Add($"{item.Producto}: {item.Total} unidades vendidas");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Estadísticas", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Clientes mas frecuentes: se agrupan con LINQ las ventas por cliente
        private void btnClientesFrecuentes_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "Clientes más frecuentes";
            lstResultados.Items.Clear();

            try
            {
                var top = VentaNegocio.ObtenerVentasConCliente()
                    .GroupBy(v => v.ClienteNombre)
                    .Select(g => new { Cliente = g.Key, Compras = g.Count() })
                    .OrderByDescending(x => x.Compras)
                    .Take(5)
                    .ToList();

                if (top.Count == 0)
                {
                    lstResultados.Items.Add("Aún no hay ventas registradas.");
                    return;
                }
                foreach (var item in top)
                    lstResultados.Items.Add($"{item.Cliente}: {item.Compras} compra(s)");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Estadísticas", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Productos con stock bajo: alerta para contactar al proveedor
        private void btnStockBajo_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "Productos con stock bajo";
            lstResultados.Items.Clear();

            try
            {
                var bajoStock = ProductoNegocio.ObtenerTodos()
                    .Where(p => p.Stock <= UmbralStockBajo)
                    .OrderBy(p => p.Stock)
                    .ToList();

                if (bajoStock.Count == 0)
                {
                    lstResultados.Items.Add("No hay productos con stock bajo.");
                    return;
                }
                foreach (var p in bajoStock)
                    lstResultados.Items.Add($"{p.Nombre} - Stock: {p.Stock}");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Estadísticas", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

﻿namespace WinFormsApp1.Formularios
{
    partial class FrmFacturacion
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            grpCliente = new GroupBox();
            cboCliente = new ComboBox();
            btnNuevoCliente = new Button();
            grpProducto = new GroupBox();
            lblBuscar = new Label();
            txtBuscar = new TextBox();
            btnBuscar = new Button();
            lblProducto = new Label();
            cboProducto = new ComboBox();
            lblCantidad = new Label();
            nudCantidad = new NumericUpDown();
            btnAgregar = new Button();
            lblCarrito = new Label();
            dgvCarrito = new DataGridView();
            btnQuitar = new Button();
            lblTotal = new Label();
            btnFinalizar = new Button();
            btnCancelar = new Button();
            grpCliente.SuspendLayout();
            grpProducto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudCantidad).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvCarrito).BeginInit();
            SuspendLayout();
            //
            // grpCliente
            //
            grpCliente.Controls.Add(cboCliente);
            grpCliente.Controls.Add(btnNuevoCliente);
            grpCliente.Location = new Point(12, 12);
            grpCliente.Name = "grpCliente";
            grpCliente.Size = new Size(660, 60);
            grpCliente.TabIndex = 0;
            grpCliente.TabStop = false;
            grpCliente.Text = "Cliente";
            //
            // cboCliente
            //
            cboCliente.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCliente.FormattingEnabled = true;
            cboCliente.Location = new Point(10, 22);
            cboCliente.Name = "cboCliente";
            cboCliente.Size = new Size(350, 23);
            cboCliente.TabIndex = 0;
            //
            // btnNuevoCliente
            //
            btnNuevoCliente.Location = new Point(370, 21);
            btnNuevoCliente.Name = "btnNuevoCliente";
            btnNuevoCliente.Size = new Size(120, 25);
            btnNuevoCliente.TabIndex = 1;
            btnNuevoCliente.Text = "Nuevo cliente...";
            btnNuevoCliente.UseVisualStyleBackColor = true;
            btnNuevoCliente.Click += btnNuevoCliente_Click;
            //
            // grpProducto
            //
            grpProducto.Controls.Add(lblBuscar);
            grpProducto.Controls.Add(txtBuscar);
            grpProducto.Controls.Add(btnBuscar);
            grpProducto.Controls.Add(lblProducto);
            grpProducto.Controls.Add(cboProducto);
            grpProducto.Controls.Add(lblCantidad);
            grpProducto.Controls.Add(nudCantidad);
            grpProducto.Controls.Add(btnAgregar);
            grpProducto.Location = new Point(12, 80);
            grpProducto.Name = "grpProducto";
            grpProducto.Size = new Size(660, 95);
            grpProducto.TabIndex = 1;
            grpProducto.TabStop = false;
            grpProducto.Text = "Agregar producto";
            //
            // lblBuscar
            //
            lblBuscar.AutoSize = true;
            lblBuscar.Location = new Point(10, 26);
            lblBuscar.Name = "lblBuscar";
            lblBuscar.Size = new Size(45, 15);
            lblBuscar.TabIndex = 0;
            lblBuscar.Text = "Buscar:";
            //
            // txtBuscar
            //
            txtBuscar.Location = new Point(75, 22);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(285, 23);
            txtBuscar.TabIndex = 1;
            //
            // btnBuscar
            //
            btnBuscar.Location = new Point(370, 21);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(75, 25);
            btnBuscar.TabIndex = 2;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += btnBuscar_Click;
            //
            // lblProducto
            //
            lblProducto.AutoSize = true;
            lblProducto.Location = new Point(10, 59);
            lblProducto.Name = "lblProducto";
            lblProducto.Size = new Size(59, 15);
            lblProducto.TabIndex = 3;
            lblProducto.Text = "Producto:";
            //
            // cboProducto
            //
            cboProducto.DropDownStyle = ComboBoxStyle.DropDownList;
            cboProducto.FormattingEnabled = true;
            cboProducto.Location = new Point(75, 55);
            cboProducto.Name = "cboProducto";
            cboProducto.Size = new Size(370, 23);
            cboProducto.TabIndex = 4;
            cboProducto.Format += cboProducto_Format;
            //
            // lblCantidad
            //
            lblCantidad.AutoSize = true;
            lblCantidad.Location = new Point(455, 59);
            lblCantidad.Name = "lblCantidad";
            lblCantidad.Size = new Size(58, 15);
            lblCantidad.TabIndex = 5;
            lblCantidad.Text = "Cantidad:";
            //
            // nudCantidad
            //
            nudCantidad.Location = new Point(519, 55);
            nudCantidad.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            nudCantidad.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            nudCantidad.Name = "nudCantidad";
            nudCantidad.Size = new Size(55, 23);
            nudCantidad.TabIndex = 6;
            nudCantidad.Value = new decimal(new int[] { 1, 0, 0, 0 });
            //
            // btnAgregar
            //
            btnAgregar.Location = new Point(580, 54);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(70, 25);
            btnAgregar.TabIndex = 7;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = true;
            btnAgregar.Click += btnAgregar_Click;
            //
            // lblCarrito
            //
            lblCarrito.AutoSize = true;
            lblCarrito.Location = new Point(12, 185);
            lblCarrito.Name = "lblCarrito";
            lblCarrito.Size = new Size(46, 15);
            lblCarrito.TabIndex = 2;
            lblCarrito.Text = "Carrito:";
            //
            // dgvCarrito
            //
            dgvCarrito.AllowUserToAddRows = false;
            dgvCarrito.AllowUserToDeleteRows = false;
            dgvCarrito.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvCarrito.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvCarrito.Location = new Point(12, 203);
            dgvCarrito.MultiSelect = false;
            dgvCarrito.Name = "dgvCarrito";
            dgvCarrito.ReadOnly = true;
            dgvCarrito.RowHeadersVisible = false;
            dgvCarrito.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCarrito.Size = new Size(660, 220);
            dgvCarrito.TabIndex = 3;
            //
            // btnQuitar
            //
            btnQuitar.Location = new Point(12, 432);
            btnQuitar.Name = "btnQuitar";
            btnQuitar.Size = new Size(130, 30);
            btnQuitar.TabIndex = 4;
            btnQuitar.Text = "Quitar producto";
            btnQuitar.UseVisualStyleBackColor = true;
            btnQuitar.Click += btnQuitar_Click;
            //
            // lblTotal
            //
            lblTotal.AutoSize = true;
            lblTotal.Location = new Point(160, 440);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(70, 15);
            lblTotal.TabIndex = 5;
            lblTotal.Text = "Total: $0.00";
            //
            // btnFinalizar
            //
            btnFinalizar.Location = new Point(412, 432);
            btnFinalizar.Name = "btnFinalizar";
            btnFinalizar.Size = new Size(130, 30);
            btnFinalizar.TabIndex = 6;
            btnFinalizar.Text = "Finalizar venta";
            btnFinalizar.UseVisualStyleBackColor = true;
            btnFinalizar.Click += btnFinalizar_Click;
            //
            // btnCancelar
            //
            btnCancelar.Location = new Point(542, 432);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(130, 30);
            btnCancelar.TabIndex = 7;
            btnCancelar.Text = "Cerrar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            //
            // FrmFacturacion
            //
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(684, 474);
            Controls.Add(btnCancelar);
            Controls.Add(btnFinalizar);
            Controls.Add(lblTotal);
            Controls.Add(btnQuitar);
            Controls.Add(dgvCarrito);
            Controls.Add(lblCarrito);
            Controls.Add(grpProducto);
            Controls.Add(grpCliente);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "FrmFacturacion";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Facturación";
            Load += FrmFacturacion_Load;
            grpCliente.ResumeLayout(false);
            grpProducto.ResumeLayout(false);
            grpProducto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudCantidad).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvCarrito).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox grpCliente;
        private ComboBox cboCliente;
        private Button btnNuevoCliente;
        private GroupBox grpProducto;
        private Label lblBuscar;
        private TextBox txtBuscar;
        private Button btnBuscar;
        private Label lblProducto;
        private ComboBox cboProducto;
        private Label lblCantidad;
        private NumericUpDown nudCantidad;
        private Button btnAgregar;
        private Label lblCarrito;
        private DataGridView dgvCarrito;
        private Button btnQuitar;
        private Label lblTotal;
        private Button btnFinalizar;
        private Button btnCancelar;
    }
}

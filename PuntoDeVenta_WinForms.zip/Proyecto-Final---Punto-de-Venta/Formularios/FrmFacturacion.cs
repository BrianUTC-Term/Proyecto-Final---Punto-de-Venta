using WinFormsApp1.Modelos;
using WinFormsApp1.Negocio;

namespace WinFormsApp1.Formularios
{
    // Punto de venta: seleccionar cliente, armar el carrito y finalizar la venta
    public partial class FrmFacturacion : Form
    {
        // Lineas del carrito de la venta actual
        private readonly List<VentaDetalle> detalles = new();

        public FrmFacturacion()
        {
            InitializeComponent();
        }

        private void FrmFacturacion_Load(object sender, EventArgs e)
        {
            CargarClientes();
            CargarProductos();
            MostrarCarrito();
        }

        private void CargarClientes()
        {
            try
            {
                cboCliente.DataSource = ClienteNegocio.ObtenerTodos();
                cboCliente.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los clientes: " + ex.Message, "Facturación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Carga los productos (todos o los que coinciden con la busqueda)
        private void CargarProductos()
        {
            try
            {
                cboProducto.DataSource = ProductoNegocio.Buscar(txtBuscar.Text.Trim());
                cboProducto.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los productos: " + ex.Message, "Facturación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Muestra precio y stock en la lista de productos
        private void cboProducto_Format(object sender, ListControlConvertEventArgs e)
        {
            if (e.ListItem is Producto p)
                e.Value = $"{p.Codigo} - {p.Nombre} - ${p.Precio:0.00} (Stock: {p.Stock})";
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarProductos();
        }

        // Abre el mantenimiento de clientes para registrar uno nuevo
        private void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            using (var frm = new FrmClientes())
            {
                frm.ShowDialog(this);
            }
            CargarClientes();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (cboProducto.SelectedItem is not Producto producto)
            {
                MessageBox.Show("Seleccione un producto.", "Facturación");
                return;
            }

            int cantidad = (int)nudCantidad.Value;

            // Si el producto ya esta en el carrito se suma la cantidad
            var existente = detalles.FirstOrDefault(d => d.ProductoId == producto.Id);
            if (existente != null)
                existente.Cantidad += cantidad;
            else
                detalles.Add(new VentaDetalle
                {
                    ProductoId = producto.Id,
                    ProductoNombre = producto.Nombre,
                    Cantidad = cantidad,
                    PrecioUnitario = producto.Precio
                });

            nudCantidad.Value = 1;
            MostrarCarrito();
        }

        private void btnQuitar_Click(object sender, EventArgs e)
        {
            if (dgvCarrito.CurrentRow?.DataBoundItem is VentaDetalle detalle)
            {
                detalles.Remove(detalle);
                MostrarCarrito();
            }
            else
            {
                MessageBox.Show("Seleccione un producto del carrito.", "Facturación");
            }
        }

        // Refresca la tabla del carrito y el total
        private void MostrarCarrito()
        {
            dgvCarrito.DataSource = null;
            dgvCarrito.DataSource = detalles.ToList();

            dgvCarrito.Columns["Id"].Visible = false;
            dgvCarrito.Columns["VentaId"].Visible = false;
            dgvCarrito.Columns["ProductoId"].Visible = false;
            dgvCarrito.Columns["ProductoNombre"].HeaderText = "Producto";
            dgvCarrito.Columns["PrecioUnitario"].HeaderText = "Precio unitario";
            dgvCarrito.Columns["PrecioUnitario"].DefaultCellStyle.Format = "0.00";
            dgvCarrito.Columns["Subtotal"].DefaultCellStyle.Format = "0.00";

            decimal total = detalles.Sum(d => d.Subtotal);
            lblTotal.Text = $"Total: ${total:0.00}";
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            if (cboCliente.SelectedItem is not Cliente cliente)
            {
                MessageBox.Show("Debes seleccionar un cliente.", "Facturación");
                return;
            }

            if (detalles.Count == 0)
            {
                MessageBox.Show("El carrito está vacío.", "Facturación");
                return;
            }

            var venta = new VentaCabecera { ClienteId = cliente.Id, Detalles = detalles.ToList() };

            try
            {
                VentaNegocio.Registrar(venta);
                MessageBox.Show($"Factura generada. Total: ${venta.Total:0.00}", "Facturación", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Se limpia la venta y se recargan los productos (el stock cambió)
                detalles.Clear();
                cboCliente.SelectedIndex = -1;
                CargarProductos();
                MostrarCarrito();
            }
            catch (NegocioException ex)
            {
                MessageBox.Show("No se pudo generar la factura: " + ex.Message, "Facturación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar la venta: " + ex.Message, "Facturación", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (detalles.Count > 0 &&
                MessageBox.Show("¿Cancelar la venta actual?", "Facturación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            Close();
        }
    }
}

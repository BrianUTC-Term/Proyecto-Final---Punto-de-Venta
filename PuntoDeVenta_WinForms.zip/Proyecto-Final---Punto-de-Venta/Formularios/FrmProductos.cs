using WinFormsApp1.Modelos;
using WinFormsApp1.Negocio;

namespace WinFormsApp1.Formularios
{
    // Mantenimiento de productos: listar, buscar, agregar, modificar y eliminar
    public partial class FrmProductos : Form
    {
        // Id del producto seleccionado (0 = producto nuevo)
        private int idSeleccionado = 0;

        public FrmProductos()
        {
            InitializeComponent();
        }

        private void FrmProductos_Load(object sender, EventArgs e)
        {
            CargarProductos();
        }

        // Carga la tabla con todos los productos o con el resultado de la busqueda
        private void CargarProductos()
        {
            try
            {
                dgvProductos.DataSource = ProductoNegocio.Buscar(txtBuscar.Text.Trim());
                dgvProductos.Columns["Precio"].DefaultCellStyle.Format = "0.00";
                dgvProductos.ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los productos: " + ex.Message, "Productos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            CargarProductos();
        }

        // Al seleccionar una fila se pasan los datos a los campos
        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            if (dgvProductos.Rows[e.RowIndex].DataBoundItem is Producto p)
            {
                idSeleccionado = p.Id;
                txtCodigo.Text = p.Codigo;
                txtNombre.Text = p.Nombre;
                txtDescripcion.Text = p.Descripcion;
                nudPrecio.Value = Math.Min(Math.Max(p.Precio, nudPrecio.Minimum), nudPrecio.Maximum);
                nudStock.Value = Math.Min(Math.Max(p.Stock, nudStock.Minimum), nudStock.Maximum);
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            var producto = new Producto
            {
                Id = idSeleccionado,
                Codigo = txtCodigo.Text.Trim(),
                Nombre = txtNombre.Text.Trim(),
                Descripcion = txtDescripcion.Text.Trim(),
                Precio = nudPrecio.Value,
                Stock = (int)nudStock.Value
            };

            try
            {
                if (idSeleccionado == 0)
                {
                    ProductoNegocio.Agregar(producto);
                    MessageBox.Show("Producto agregado.", "Productos");
                }
                else
                {
                    ProductoNegocio.Actualizar(producto);
                    MessageBox.Show("Producto actualizado.", "Productos");
                }

                Limpiar();
                CargarProductos();
            }
            catch (NegocioException ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Productos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message, "Productos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un producto de la lista.", "Productos");
                return;
            }

            if (MessageBox.Show("¿Confirmar eliminación?", "Productos", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                ProductoNegocio.Eliminar(idSeleccionado);
                MessageBox.Show("Producto eliminado.", "Productos");
                Limpiar();
                CargarProductos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo eliminar: " + ex.Message, "Productos", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }

        // Deja los campos listos para un producto nuevo
        private void Limpiar()
        {
            idSeleccionado = 0;
            txtCodigo.Clear();
            txtNombre.Clear();
            txtDescripcion.Clear();
            nudPrecio.Value = 0;
            nudStock.Value = 0;
            dgvProductos.ClearSelection();
            txtCodigo.Focus();
        }
    }
}
